########################################################################
## Welcome to the USRP source code tree
########################################################################

host/

    Description: source code for user-space driver

firmware/

    Description: source code for various micro processors

fpga/

    Description: source code for FPGA designs

images/

    Description: package builder for FPGA and firmware images
